package com.demo.cg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Launch {
	
	public static void main (String[] args) throws InterruptedException 
	
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//open the web page
		driver.navigate().to("https://www.amazon.in/");
		driver.manage().window().maximize();
		String title = driver.getTitle();
		
		//search box
		WebElement SearchBox = driver.findElement(By.id("twotabsearchtextbox"));
		SearchBox.sendKeys("books");
		WebElement SearchIcon = driver.findElement(By.className("nav-input"));
		SearchIcon.click();	
		Thread.sleep(5000);
		
		
		//Selecting		
		driver.findElement(By.partialLinkText("Ikigai")).click();
		Thread.sleep(2000);
		
		//Shift the tabs
		
		java.util.Set<String> handles = driver.getWindowHandles();
		String  winHandle1 = driver.getWindowHandle();
		handles.remove(winHandle1);
		
		String winHandle = handles.iterator().next();
		String winHandle2 = "";
		if(winHandle!= winHandle1)
		{
			winHandle2 = winHandle;
			
			driver.switchTo().window(winHandle2);
			System.out.println(winHandle2);
			
		}		
		Thread.sleep(2000);
		
		
		//Adding to cart
		driver.findElement(By.id("add-to-cart-button")).click();
		Thread.sleep(2000);
		
		//proceeding to buy
		WebElement Proceedtobuy = driver.findElement(By.id("hlb-ptc-btn-native"));
		Proceedtobuy.click();
		
		//entering number
		WebElement Email = driver.findElement(By.id("ap_email"));
		Email.sendKeys("8522969686");
		WebElement Continue = driver.findElement(By.id("continue"));
		Continue.click();
		
		//password
		WebElement password = driver.findElement(By.id("ap_password"));
		password.sendKeys("Tomjerry");
		WebElement Login = driver.findElement(By.id("signInSubmit"));
		Login.click();
		
	}

}
