package com.cg;

import java.util.Scanner;

public class Admin {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		EmployeeSchedular empsch = new EmployeeSchedular();
		int menuNumber = 1;
		do {

			System.out.println();
			System.out.println();
			System.out.println("***------------WECOME-----------***");
			System.out.println("1. Add Employee");
			System.out.println("2. Display all Employees");
			System.out.println("3. Display Employee by Employee Id");
			System.out.println("4. Display employee by Employee Designation");
			System.out.println("5. Exit");
			System.out.print("Enter the option Number :");

			menuNumber = sc.nextInt();

			switch (menuNumber) {
			case 1: {
				System.out.println("Enter a employee Id :");
				int empId = sc.nextInt();

				System.out.println("Enter Employee Name ;");
				String name = sc.next();

				System.out.println("Enter Employee Designation :");
				String designation = sc.next();

				System.out.println("Enter Employrr Salary :");
				double salary = sc.nextInt();

				System.out.println("Enter Employee flat number :");
				String flatNo = sc.next();

				System.out.println("Enter Employee Street name :");
				String streetName = sc.next();

				System.out.println("Enter employee City :");
				String city = sc.next();

				System.out.println(empsch.addEmployee(empId, name, designation, salary, flatNo, streetName, city));

				break;
			}
			case 2: {
				empsch.displayAllEmployeeDetails();
				break;
			}
			case 3: {
				System.out.println("Enter Employee Id :");
				empsch.dispayEmployeeById(sc.nextInt());
				break;
			}
			case 4: {
				System.out.println("Enter Employee Designation");
				empsch.displayEmployeeByDesignation(sc.next());
				break;
			}
			case 5:
				System.out.println("______________THANK YOU_______________");
				break;
			}
		} while (menuNumber != 5);

		sc.close();

	}

}
