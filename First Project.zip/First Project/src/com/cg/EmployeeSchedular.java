package com.cg;

public class EmployeeSchedular {

	private Employee[] employees = new Employee[10];
	private int counterEmployee;

	public String addEmployee(int empId, String name, String designation, double salary,
			String flatNo, String street,
			String city) {
		
		if(validateEmpId(empId)) {
			employees[counterEmployee] = new Employee();
			employees[counterEmployee].setEmpId(empId);
			employees[counterEmployee].setName(name);
			employees[counterEmployee].setDesignation(designation);
			employees[counterEmployee].setSalary(salary);
			
			Address address = new Address();
			address.setFlatNo(flatNo);
			address.setStreet(street);
			address.setCity(city);
			
			employees[counterEmployee].setAddress(address);
			
			counterEmployee++;
			
			return "employee details added successfully";
		}
		else {
			return "employee details adding failed as Employee Id already exist";
		}
	}

	public void displayAllEmployeeDetails() {
		for (int i = 0; i < counterEmployee; i++) {
			System.out.println(employees[i].getEmpId());
			System.out.println(employees[i].getName());
			System.out.println(employees[i].getDesignation());
			System.out.println(employees[i].getSalary());
			System.out.println(employees[i].getAddress().getFlatNo());
			System.out.println(employees[i].getAddress().getStreet());
			System.out.println(employees[i].getAddress().getCity());
			System.out.println();
		}

	}

	public void dispayEmployeeById(int empId) {
		int flag = 0;
		for (int i = 0; i < counterEmployee; i++) {
			if (empId == employees[i].getEmpId()) {
				System.out.println(employees[i].getEmpId());
				System.out.println(employees[i].getName());
				System.out.println(employees[i].getDesignation());
				System.out.println(employees[i].getSalary());
				System.out.println(employees[i].getAddress().getFlatNo());
				System.out.println(employees[i].getAddress().getStreet());
				System.out.println(employees[i].getAddress().getCity());
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			System.out.println("Employee Id doesn't exist");
		}
	}

	public void displayEmployeeByDesignation(String designation) {
		int flag = 0;
		for (int i = 0; i < counterEmployee; i++) {
			if (designation.equals(employees[i].getDesignation())) {
				System.out.println(employees[i].getEmpId());
				System.out.println(employees[i].getName());
				System.out.println(employees[i].getDesignation());
				System.out.println(employees[i].getSalary());
				System.out.println(employees[i].getAddress().getFlatNo());
				System.out.println(employees[i].getAddress().getStreet());
				System.out.println(employees[i].getAddress().getCity());
				System.out.println();
				flag = 1;
			}
		}
		if(flag == 0) {
			System.out.println("Entered employee designation is INVALID");
		}
	}

	public boolean validateEmpId(int empId) {
		boolean flag = true;
		for (int i = 0; i < counterEmployee; i++) {
			if (empId == employees[i].getEmpId()) {
				flag = false;
				break;
			}
		}

		return flag;
	}

}
