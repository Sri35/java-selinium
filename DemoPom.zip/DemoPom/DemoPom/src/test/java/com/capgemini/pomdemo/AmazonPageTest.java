package com.capgemini.pomdemo;

import static org.junit.Assert.assertTrue;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AmazonPageTest extends FunctionalTest {
	
	@Test
	public void a_searchPage() {
		driver.get("http://www.amazon.in");
		driver.manage().window().maximize();
		
		SearchPage searchPage=new SearchPage(driver);
		assertTrue(searchPage.isInitialized());
		
		searchPage.searchProduct("watch");
		ProductPage booksPage=searchPage.submit();
		assertTrue(booksPage.isInitialized());
	}
	
	@Test
	public void bookPage() {
		ProductPage productPage=new ProductPage(driver);
		assertTrue(productPage.isInitialized());
		AddToCartPage addToCartPage=productPage.selectBook();
		assertTrue(addToCartPage.switchToNewWindow());
		assertTrue(addToCartPage.isInitialized());
	}
	
	@Test
	public void c_addToCartPage() {
		AddToCartPage addToCartPage=new AddToCartPage(driver);
		assertTrue(addToCartPage.isInitialized());
		ProccedToBuyPage procedBuyPage=addToCartPage.addProductToCart();
		assertTrue(procedBuyPage.isInitialized());
	}
	
	@Test
	public void proceedBuyPage() {
		ProccedToBuyPage proceedToBuyPage=new ProccedToBuyPage(driver);
		assertTrue(proceedToBuyPage.isInitialized());
		assertTrue(proceedToBuyPage.proceedToBuy());
	}

}
