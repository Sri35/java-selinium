package com.capgemini.pomdemo;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class AddToCartPage extends PageObject{

	public AddToCartPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(id = "add-to-cart-button")
	private WebElement addToCart;
	
		
	public boolean isInitialized() {
		return addToCart.isDisplayed();
	}
	
		
	public boolean  switchToNewWindow() {
		String parent=driver.getWindowHandle();
		Set<String> windowHandles=driver.getWindowHandles();
		Iterator<String> iterator= windowHandles.iterator();
		while(iterator.hasNext())
		{
			String child_window=iterator.next();
			if(!parent.equals(child_window))
			{
				driver.switchTo().window(child_window);
				System.out.println(driver.switchTo().window(child_window).getTitle());
			}
		}
		return true;
	}	
	public ProccedToBuyPage addProductToCart() {
		addToCart.click();
		return new ProccedToBuyPage(driver);
	}
	
	
	

}
