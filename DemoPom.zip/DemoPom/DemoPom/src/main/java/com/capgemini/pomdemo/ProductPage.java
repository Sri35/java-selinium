package com.capgemini.pomdemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductPage extends PageObject {

	public ProductPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(partialLinkText = "Quartz Analog Blue")
	private WebElement product;
	
	
	
	public boolean isInitialized() {
		return product.isDisplayed();
	}
	
	public AddToCartPage selectBook() {
		product.click();
		return new AddToCartPage(driver);
	}
	
	
}
