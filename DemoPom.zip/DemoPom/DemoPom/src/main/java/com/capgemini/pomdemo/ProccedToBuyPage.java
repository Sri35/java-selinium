package com.capgemini.pomdemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProccedToBuyPage extends PageObject{

	public ProccedToBuyPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(partialLinkText = "Proceed to Buy")
	private WebElement buy;
	
	public boolean isInitialized() {
		return buy.isDisplayed();
	}
	
	public boolean proceedToBuy() {
		buy.click();
		return true;
	}

}
