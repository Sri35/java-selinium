package com.capgemini.pomdemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchPage extends PageObject {
	
	@FindBy(id="twotabsearchtextbox")
	private WebElement search;
	
	
	public SearchPage(WebDriver driver) {
		super(driver);
	}

	public boolean isInitialized() {
		return search.isDisplayed();
	}
	
	public void searchProduct(String search) {
		this.search.sendKeys(search);
	}
	public ProductPage submit(){
		search.submit();
		return new ProductPage(driver);
	}

}
